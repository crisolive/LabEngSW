package com.example.cliente.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.cliente.Model.Cliente;
import com.example.cliente.Repository.ClienteRepositoy2;

@Service
public class ClienteService {

    @Autowired
    ClienteRepositoy2 repository;

    public Cliente createCliente(Cliente cliente){
        repository.save(cliente);
        return cliente;
    }
    
}
