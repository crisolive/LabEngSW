package com.example.cliente.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.cliente.Model.Cliente;

@Repository
public interface ClienteRepositoy2 extends JpaRepository<Cliente, Long>{
    
}
